<?php

namespace App\Http\Controllers;

use App\avi;
use Illuminate\Http\Request;

class AviController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\avi  $avi
     * @return \Illuminate\Http\Response
     */
    public function show(avi $avi)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\avi  $avi
     * @return \Illuminate\Http\Response
     */
    public function edit(avi $avi)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\avi  $avi
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, avi $avi)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\avi  $avi
     * @return \Illuminate\Http\Response
     */
    public function destroy(avi $avi)
    {
        //
    }
}
