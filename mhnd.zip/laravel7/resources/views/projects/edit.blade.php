@extends('layouts.app')
@section('content')
    <h1 class="mt-5 pt-5">edit project who has is {{$id}}</h1>
@endsection