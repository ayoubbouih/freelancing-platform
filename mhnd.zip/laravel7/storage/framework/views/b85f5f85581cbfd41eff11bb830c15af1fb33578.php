<?php $__env->startSection('content'); ?>
    <h1 class="mt-5 pt-5">intitule du projet est  <?php echo e($projet->intitule); ?></h1>
    <p><?php echo e($projet->user->email); ?></p>
    
    <?php $__currentLoopData = $projet->postes->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poste): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($poste->intitule); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dev\laravel7\resources\views/projects/show.blade.php ENDPATH**/ ?>