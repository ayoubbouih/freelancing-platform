<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\conversastion;
use Faker\Generator as Faker;

$factory->define(conversastion::class, function (Faker $faker) {
    return [
        //
    ];
});
