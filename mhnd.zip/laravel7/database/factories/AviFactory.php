<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\avi;
use Faker\Generator as Faker;

$factory->define(avi::class, function (Faker $faker) {
    return [
        //
    ];
});
