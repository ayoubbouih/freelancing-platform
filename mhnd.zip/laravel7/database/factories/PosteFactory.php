<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\poste;
use Faker\Generator as Faker;

$factory->define(poste::class, function (Faker $faker) {
    return [
        //
    ];
});
