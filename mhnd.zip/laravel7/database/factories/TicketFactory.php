<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\ticket;
use Faker\Generator as Faker;

$factory->define(ticket::class, function (Faker $faker) {
    return [
        //
    ];
});
