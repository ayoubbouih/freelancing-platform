<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\experience;
use Faker\Generator as Faker;

$factory->define(experience::class, function (Faker $faker) {
    return [
        //
    ];
});
