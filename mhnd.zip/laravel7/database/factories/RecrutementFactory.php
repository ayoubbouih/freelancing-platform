<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\recrutement;
use Faker\Generator as Faker;

$factory->define(recrutement::class, function (Faker $faker) {
    return [
        //
    ];
});
