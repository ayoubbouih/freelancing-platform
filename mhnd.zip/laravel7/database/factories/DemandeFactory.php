<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\demande;
use Faker\Generator as Faker;

$factory->define(demande::class, function (Faker $faker) {
    return [
        //
    ];
});
