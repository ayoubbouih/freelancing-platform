<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\paiement;
use Faker\Generator as Faker;

$factory->define(paiement::class, function (Faker $faker) {
    return [
        //
    ];
});
